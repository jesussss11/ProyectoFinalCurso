import { PiprefPipe } from './pipref.pipe';

describe('PiprefPipe', () => {
  it('create an instance', () => {
    const pipe = new PiprefPipe();
    expect(pipe).toBeTruthy();
  });
});
