import { PipeasocPipe } from './pipeasoc.pipe';

describe('PipeasocPipe', () => {
  it('create an instance', () => {
    const pipe = new PipeasocPipe();
    expect(pipe).toBeTruthy();
  });
});
