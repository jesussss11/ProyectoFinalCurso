import { PiperfilPipe } from './piperfil.pipe';

describe('PiperfilPipe', () => {
  it('create an instance', () => {
    const pipe = new PiperfilPipe();
    expect(pipe).toBeTruthy();
  });
});
