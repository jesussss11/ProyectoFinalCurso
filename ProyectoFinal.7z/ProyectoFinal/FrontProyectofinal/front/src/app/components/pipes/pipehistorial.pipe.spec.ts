import { PipehistorialPipe } from './pipehistorial.pipe';

describe('PipehistorialPipe', () => {
  it('create an instance', () => {
    const pipe = new PipehistorialPipe();
    expect(pipe).toBeTruthy();
  });
});
