import { PipasPipe } from './pipas.pipe';

describe('PipasPipe', () => {
  it('create an instance', () => {
    const pipe = new PipasPipe();
    expect(pipe).toBeTruthy();
  });
});
