export class AsociacionModel {

    id: string;
    nombre: string;
    direccion: string;
    telefono: string;
    cif: string;
    correo: string;
    preferencias: string;
    logo: string;
    password: string;
    rol: 2;//2

}
