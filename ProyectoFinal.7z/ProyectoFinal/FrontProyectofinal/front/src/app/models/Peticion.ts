export class Peticionmodel{
id: string;
id_asoc: string;
id_user: string;
nombre_asoc: string;
nombre_user: string;
descripcion: string;
estado: string;

}