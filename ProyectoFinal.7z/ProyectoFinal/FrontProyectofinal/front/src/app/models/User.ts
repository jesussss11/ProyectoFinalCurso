export class UserModel {

    id: string;
    nombre: string;
    direccion: string;
    telefono: string;
    dni: string;
    email: string;
    password: string;
    rol: string;
    cif: string;
    preferencias: string;
    
    
   

}