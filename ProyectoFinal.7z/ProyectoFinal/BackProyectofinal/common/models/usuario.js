'use strict';

module.exports = function(Usuario) {

};
