'use strict';

module.exports = function(Peticion) {

};
