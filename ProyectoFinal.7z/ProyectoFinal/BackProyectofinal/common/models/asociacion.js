'use strict';

module.exports = function(Asociacion) {

};
