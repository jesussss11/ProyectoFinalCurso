'use strict';

module.exports = function(Historial) {

};
